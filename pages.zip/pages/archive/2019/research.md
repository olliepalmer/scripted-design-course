---
layout: page
title: Research
parent: 2019
permalink: /2019/research
nav_order: 4
has_toc: false
---

# Studio research

We're going to collectively research script-based artworks!

To contribute, [click here](http://bit.ly/constrained-artworks).

Here's the research so far:

<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vRiGVvjiLuwzt3r8cbQd1l8RJAwrHL3S7Df3KnVY1cEBgoXGvtMmnYE-rEWTVGq7snsI9FTfSj-oQHO/embed?start=false&loop=false&delayms=60000" frameborder="0" width="100%" height="1000" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
