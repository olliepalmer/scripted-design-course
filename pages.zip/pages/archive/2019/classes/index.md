---
layout: page
title: Classes 2019
parent: 2019
permalink: /2019/classes/
nav_order: 2
has_toc: true
has_children: true
---

# Classes

## This course ran on Fridays from 27 September until 06 December 2019.

## Classes were posted here shortly after they happened.
